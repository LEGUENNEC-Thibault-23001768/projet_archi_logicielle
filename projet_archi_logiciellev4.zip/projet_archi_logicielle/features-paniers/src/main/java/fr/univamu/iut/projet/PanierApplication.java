package fr.univamu.iut.projet;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/api")
public class PanierApplication extends Application {
}