<?php
include 'includes/config.php'; // Inclure la config et démarrer la session
include 'includes/header.php';

$panierIdParam = filter_input(INPUT_GET, 'panierId', FILTER_VALIDATE_INT);
$panierData = null; // Will be fetched by JS now mostly
$produitsDetails = [];
$error = null;
$token = getAuthToken(); // Get from PHP session
$userId = getUserId(); // Get from PHP session

// --- Simulation Points Relais (Keep as is for now) ---
$relais = [
    ['id' => 1, 'nom' => 'Relais Ferme du Pré', 'adresse' => '12 Rue des Champs, 75000 Paris'],
    ['id' => 2, 'nom' => 'Boutique Bio Coop', 'adresse' => '5 Avenue Verte, 75000 Paris'],
    ['id' => 3, 'nom' => 'Marché Central', 'adresse' => 'Place du Marché, 75000 Paris']
];
// --- Fin Simulation ---

if (!$token || !$userId) {
     $error = "Veuillez vous connecter pour finaliser une commande.";
} elseif (!$panierIdParam) {
    // Try getting from JS storage if not in URL (e.g., direct navigation)
    // $panierIdParam = ??? // Cannot access JS localStorage from PHP directly
    // Best approach: Rely on URL param or ensure JS always navigates here WITH the param.
    $error = "ID de panier manquant pour la commande.";
}

// **PHP Data Fetching Removed**: We'll fetch Panier & Product details dynamically using JS
// to ensure consistency with the cart page and handle potential updates.
// PHP just sets up the structure.

?>

<main class="commande-page">
    <h1>Finaliser votre commande</h1>

    <?php if ($error): ?>
        <div class="alert error"><?= htmlspecialchars($error) ?></div>
        <p style="text-align:center;"><a href="/paniers.php" class="browse-btn">Retour au panier</a></p>
    <?php else: ?>
        <div id="commande-loading" style="text-align: center; padding: 30px;">Chargement du récapitulatif...</div>
        <div id="commande-error" class="alert error" style="display: none;"></div>

        <div class="commande-container" id="commande-content" style="display:none;">
            <!-- Récapitulatif du panier (populated by JS) -->
            <section class="panier-summary">
                <h2>Votre panier</h2>
                <div class="panier-card">
                    <img id="panier-image" src="/images/placeholder.jpg" alt="Panier"> <!-- Placeholder image -->
                    <div class="panier-details">
                        <h3 id="panier-nom">Panier #<?= htmlspecialchars($panierIdParam) ?></h3>
                        <p class="description" id="panier-description">Récapitulatif des produits.</p>
                        <p class="price" id="panier-total-recap">0.00 €</p>

                        <h4>Contenu :</h4>
                        <ul class="produits-list" id="panier-produits-recap">
                            <!-- Items populated by JS -->
                        </ul>
                    </div>
                </div>
            </section>

            <!-- Formulaire de commande -->
            <section class="commande-form">
                <h2>Informations de retrait</h2>
                <form id="commande-final-form" method="POST"> <!-- JS Handled -->
                    <input type="hidden" name="panier_id" value="<?= htmlspecialchars($panierIdParam) ?>">
                    <input type="hidden" name="client_id" value="<?= htmlspecialchars($userId) ?>"> <!-- Pass User/Client ID -->

                    <div class="form-group">
                        <label for="relai">Point de retrait</label>
                        <select id="relai" name="relaiId" required> <!-- Name matches Commande.java setter -->
                            <option value="">Choisissez un relai</option>
                            <?php foreach ($relais as $relai): ?>
                                <option value="<?= $relai['id'] ?>">
                                    <?= htmlspecialchars($relai['nom']) ?> - <?= htmlspecialchars($relai['adresse']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="date_retrait">Date de retrait</label>
                         <!-- Name matches Commande.java setter -->
                        <input type="date" id="date_retrait" name="dateRetrait" min="<?= date('Y-m-d') ?>" required>
                    </div>

                    <!-- Commentaires are not in Commande.java entity, remove or add to API if needed -->
                    <!-- <div class="form-group">
                        <label for="commentaires">Commentaires (optionnel)</label>
                        <textarea id="commentaires" name="commentaires" rows="3"></textarea>
                    </div> -->

                    <div class="total-section">
                        <p class="total-label">Total à payer :</p>
                        <p class="total-price" id="form-total-price">0.00 €</p>
                        <small>Paiement lors du retrait du panier.</small>
                    </div>

                    <button type="submit" class="commander-btn" id="confirm-commande-btn" disabled>Confirmer la commande</button>
                    <div id="confirm-error" class="alert error" style="display: none; margin-top: 15px;"></div>
                </form>
            </section>
        </div>
    <?php endif; ?>
</main>

<script>
// Assume helper functions (getAuthTokenJs, fetchApiJs etc.) are available
const panierId = <?= json_encode($panierIdParam) ?>;
const clientId = <?= json_encode($userId) ?>; // User ID from PHP Session
const token = getAuthTokenJs(); // Get token from localStorage

const loadingDiv = document.getElementById('commande-loading');
const errorDiv = document.getElementById('commande-error');
const contentDiv = document.getElementById('commande-content');
const confirmBtn = document.getElementById('confirm-commande-btn');
const confirmErrorDiv = document.getElementById('confirm-error');

let fetchedPanierData = null;
let calculatedTotal = 0;
let productDetailsCmdCache = {}; // Separate cache or reuse global one

// Fetch product details (similar to panier page)
async function fetchProductDetailsCmd(productId, token) {
     if (productDetailsCmdCache[productId]) return productDetailsCmdCache[productId];
     if (!productId) return null;
     try {
         const url = `${API_PRODUCTS_USERS_URL_JS}/products/${productId}`;
         const details = await fetchApiJs(url, 'GET', null, token);
         productDetailsCmdCache[productId] = details || { nom: `Produit ${productId} (introuvable)`, prix: 0 };
         return productDetailsCmdCache[productId];
     } catch (error) {
         console.error(`Error fetching details for product ${productId}:`, error);
         productDetailsCmdCache[productId] = { nom: `Produit ${productId} (erreur)`, prix: 0 };
         return productDetailsCmdCache[productId];
     }
}


// Load panier details and render the summary
async function loadCommandeSummary() {
    loadingDiv.style.display = 'block';
    errorDiv.style.display = 'none';
    contentDiv.style.display = 'none';
    confirmBtn.disabled = true;

    if (!panierId || !token || !clientId) {
        loadingDiv.style.display = 'none';
        errorDiv.textContent = "Informations utilisateur ou panier manquantes.";
        errorDiv.style.display = 'block';
        return;
    }

    try {
        // 1. Fetch Panier data
        const panierUrl = `${API_PANIERS_URL_JS}/paniers/${panierId}`;
        fetchedPanierData = await fetchApiJs(panierUrl, 'GET', null, token);

        if (!fetchedPanierData || !fetchedPanierData.panierProduits || fetchedPanierData.panierProduits.length === 0) {
            throw new Error("Le panier est vide ou n'a pas pu être chargé.");
        }

        // 2. Fetch Product details for all items
        const detailPromises = fetchedPanierData.panierProduits.map(item => fetchProductDetailsCmd(item.productId, token));
        await Promise.all(detailPromises);

        // 3. Render Summary and Calculate Total
        const recapList = document.getElementById('panier-produits-recap');
        recapList.innerHTML = ''; // Clear any previous
        calculatedTotal = 0;

        fetchedPanierData.panierProduits.forEach(item => {
            const details = productDetailsCmdCache[item.productId];
            if (!details) return;

            const li = document.createElement('li');
            const lineTotal = (details.prix || 0) * item.quantity;
            li.textContent = `${details.nom} - ${item.quantity} ${item.unit} (${lineTotal.toFixed(2)} €)`;
            recapList.appendChild(li);
            calculatedTotal += lineTotal;
        });

        // Update totals display
        document.getElementById('panier-total-recap').textContent = `${calculatedTotal.toFixed(2)} €`;
        document.getElementById('form-total-price').textContent = `${calculatedTotal.toFixed(2)} €`;
        // Update other placeholders if needed (image, desc)
         document.getElementById('panier-image').src = 'https://i.postimg.cc/8CJXbKQJ/fermier.jpg'; // Default img

        // Show content, hide loading
        loadingDiv.style.display = 'none';
        contentDiv.style.display = 'grid'; // Use grid as per CSS
        confirmBtn.disabled = false; // Enable confirmation button


    } catch (error) {
        loadingDiv.style.display = 'none';
        errorDiv.textContent = "Erreur chargement récapitulatif: " + error.message;
        errorDiv.style.display = 'block';
        console.error("Error loading commande summary:", error);
    }
}

// Handle Form Submission
document.getElementById('commande-final-form')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    confirmBtn.disabled = true;
    confirmBtn.textContent = 'Confirmation...';
    confirmErrorDiv.style.display = 'none';
    confirmErrorDiv.textContent = '';

    const formData = new FormData(e.target);
    const commandeData = {
        clientId: parseInt(clientId), // From PHP/JS variable
        panierId: parseInt(panierId), // From PHP/JS variable
        relaiId: parseInt(formData.get('relaiId')), // Matches select name
        dateRetrait: formData.get('dateRetrait'), // Matches input name
        prixTotal: calculatedTotal, // Use the calculated total
        statut: 'EN_ATTENTE' // Default status for new orders
        // Ensure field names match Commande.java exactly
    };

    // Validate required fields client-side
    if (!commandeData.relaiId || !commandeData.dateRetrait) {
         confirmErrorDiv.textContent = 'Veuillez choisir un point relais et une date de retrait.';
         confirmErrorDiv.style.display = 'block';
         confirmBtn.disabled = false;
         confirmBtn.textContent = 'Confirmer la commande';
         return;
    }


    const apiUrl = `${API_COMMANDES_URL_JS}/commandes`; // POST to Commandes API

    try {
        const createdCommande = await fetchApiJs(apiUrl, 'POST', commandeData, token);
        console.log("Commande created:", createdCommande);

        // Success - maybe clear panierId from local storage? Or leave it?
        // setPanierIdJs(null); // Optional: Clear panier after order

        alert('Commande confirmée avec succès ! Numéro : ' + (createdCommande.id || 'N/A'));
        // Redirect to a confirmation page or espace client
        window.location.href = '/espace-client.php?commandeSuccess=1&id=' + (createdCommande.id || '');

    } catch (error) {
        console.error("Erreur commande:", error);
        confirmErrorDiv.textContent = "Erreur lors de la confirmation: " + error.message;
        confirmErrorDiv.style.display = 'block';
        confirmBtn.disabled = false;
        confirmBtn.textContent = 'Confirmer la commande';
    }
});

// --- Initial Load ---
document.addEventListener('DOMContentLoaded', loadCommandeSummary);

</script>


<?php include 'includes/footer.php'; ?>