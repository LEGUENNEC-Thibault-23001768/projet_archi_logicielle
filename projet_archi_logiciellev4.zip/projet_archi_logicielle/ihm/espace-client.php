<?php
include 'includes/config.php';
include 'includes/header.php';

$token = getAuthToken();
$userId = getUserId();

if (!$token || !$userId) {
    header('Location: /login.php?redirect=espace-client.php');
    exit();
}

$userData = null;
$userError = null;
$commandesData = null;
$commandesError = null;

// Fetch User Details
$userApiResponse = fetchFromApi('/users/' . $userId, 'GET', null, $token);
if (isset($userApiResponse['error'])) {
    $userError = "Impossible de charger les informations utilisateur: " . $userApiResponse['error'];
} else {
    $userData = $userApiResponse;
}

// Fetch User's Commandes (Requires API endpoint adjustment)
// TODO: The Commandes API needs an endpoint like GET /commandes?clientId={userId}
// For now, we fetch ALL commands and filter client-side (INEFFICIENT!) or just show placeholder.

/* // Example of fetching ALL and filtering (Not recommended for production)
$commandesApiResponse = fetchFromApi('/commandes', 'GET', null, $token);
if (isset($commandesApiResponse['error'])) {
    $commandesError = "Impossible de charger l'historique des commandes: " . $commandesApiResponse['error'];
    $commandesData = [];
} elseif (is_array($commandesApiResponse)) {
     // Filter commands belonging to the current user
     $commandesData = array_filter($commandesApiResponse, function($commande) use ($userId) {
         return isset($commande['clientId']) && $commande['clientId'] == $userId; // Ensure clientId is present and matches
     });
} else {
     $commandesError = "Réponse inattendue de l'API commandes.";
     $commandesData = [];
}
*/
// Using placeholder for now as filtering all is bad practice
$commandesError = "Fonctionnalité d'historique non disponible (API manquante).";


?>

<main class="espace-client-page" style="max-width: 900px; margin: 20px auto; padding: 20px;">
    <h1>Mon Espace Client</h1>

    <?php if (isset($_GET['commandeSuccess'])): ?>
        <div class="alert success">Votre commande a été confirmée avec succès !</div>
    <?php endif; ?>

    <section class="user-info" style="margin-bottom: 30px; background: #f9f9f9; padding: 20px; border-radius: 8px;">
        <h2>Mes Informations</h2>
        <?php if ($userError): ?>
            <div class="alert error"><?= htmlspecialchars($userError) ?></div>
        <?php elseif ($userData): ?>
            <p><strong>Nom:</strong> <?= htmlspecialchars($userData['nom'] ?? 'N/A') ?></p>
            <p><strong>Email:</strong> <?= htmlspecialchars($userData['email'] ?? 'N/A') ?></p>
            <p><strong>Role:</strong> <?= htmlspecialchars($userData['role'] ?? 'N/A') ?></p>
            <!-- Add link to edit profile if functionality exists -->
        <?php else: ?>
            <p>Chargement des informations...</p>
        <?php endif; ?>
    </section>

    <section class="commandes-history">
        <h2>Historique des Commandes</h2>
        <?php if ($commandesError): ?>
            <div class="alert error"><?= htmlspecialchars($commandesError) ?></div>
        <?php elseif (empty($commandesData)): ?>
            <p>Vous n'avez pas encore passé de commande.</p>
        <?php else: ?>
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="background-color: #eee;">
                        <th style="padding: 10px; border: 1px solid #ddd;">ID Commande</th>
                        <th style="padding: 10px; border: 1px solid #ddd;">Date Retrait</th>
                        <th style="padding: 10px; border: 1px solid #ddd;">Total</th>
                        <th style="padding: 10px; border: 1px solid #ddd;">Statut</th>
                        <th style="padding: 10px; border: 1px solid #ddd;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($commandesData as $commande): ?>
                        <tr>
                            <td style="padding: 10px; border: 1px solid #ddd;"><?= htmlspecialchars($commande['id']) ?></td>
                            <td style="padding: 10px; border: 1px solid #ddd;"><?= htmlspecialchars($commande['dateRetrait'] ?? 'N/A') ?></td>
                            <td style="padding: 10px; border: 1px solid #ddd;"><?= number_format($commande['prixTotal'] ?? 0, 2, ',', ' ') ?> €</td>
                            <td style="padding: 10px; border: 1px solid #ddd;"><?= htmlspecialchars($commande['statut'] ?? 'N/A') ?></td>
                            <td style="padding: 10px; border: 1px solid #ddd;">
                                <?php if (($commande['statut'] ?? '') === 'EN_ATTENTE'): ?>
                                    <!-- Add JS later for cancel button -->
                                    <button class="cancel-btn" data-commande-id="<?= $commande['id'] ?>" style="padding: 5px 8px; background: #f44336; color: white; border: none; border-radius: 3px; cursor: pointer;">Annuler</button>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </section>

</main>

<?php include 'includes/footer.php'; ?>