<footer class="main-footer" style="text-align: center; padding: 20px; margin-top: 40px; background-color: #f2f2f2; color: #555;">
        <p>© <?= date('Y') ?> Coopérative Agricole. Tous droits réservés.</p>
        <!-- Add more footer content if needed -->
    </footer>

    <!-- ================================================== -->
    <!-- SCRIPT INCLUDES - ORDER MATTERS -->
    <!-- ================================================== -->

    <!-- 1. Include the common helper functions FIRST -->
    <!-- Ensure this path is correct relative to your web root -->
    <script src="/js/api-helpers.js"></script>

    <!-- 2. Include any other global libraries or scripts here if needed -->
    <!-- Example: <script src="/libs/some-library.js"></script> -->

    <!-- 3. Global handlers (like logout/success message) -->
    <script>
         // This runs once the DOM is ready and api-helpers.js should be loaded
         document.addEventListener('DOMContentLoaded', () => {
            const urlParams = new URLSearchParams(window.location.search);

            // --- Logout Handler ---
            if (urlParams.has('logout')) {
                console.log('Logout detected, clearing local storage...');

                // Use helper function if it exists, otherwise direct access
                if (typeof setPanierIdJs === 'function') {
                    setPanierIdJs(null); // Clear panierId using helper
                } else {
                    console.warn('setPanierIdJs helper not found during logout cleanup.'); // Warn if helper missing
                    localStorage.removeItem('panierId');
                }
                localStorage.removeItem('authToken');
                localStorage.removeItem('userId');

                // Clean URL without reloading page
                if (history.replaceState) {
                     const cleanURL = window.location.protocol + "//" + window.location.host + window.location.pathname;
                     history.replaceState({path:cleanURL}, '', cleanURL);
                }

                // Display a "Logged out" message temporarily
                const logoutMsg = document.createElement('div');
                logoutMsg.textContent = 'Vous avez été déconnecté.';
                // Applying styles directly for simplicity, consider CSS classes
                logoutMsg.style.cssText = `
                    position: fixed;
                    top: 10px;
                    left: 50%;
                    transform: translateX(-50%);
                    background-color: #e8f5e9; /* Light green background */
                    color: #2e7d32; /* Dark green text */
                    padding: 10px 20px;
                    border-radius: 5px;
                    border: 1px solid #a5d6a7; /* Light green border */
                    z-index: 2000; /* Ensure it's on top */
                    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                    font-size: 0.9em;
                    text-align: center;
                `;
                document.body.appendChild(logoutMsg);
                // Remove the message after a few seconds
                setTimeout(() => {
                     logoutMsg.style.transition = 'opacity 0.5s ease-out';
                     logoutMsg.style.opacity = '0';
                     setTimeout(() => { logoutMsg.remove(); }, 500); // Remove from DOM after fade
                }, 3000); // Display duration
            }

            // --- Commande Success Handler (Optional Actions) ---
             if (urlParams.has('commandeSuccess')) {
                 // Example: Log that the success parameter was detected
                 console.log('Page loaded after successful command. Parameter detected.');

                 // You might want to clear the panier ID from localStorage here,
                 // but be careful if the user might want to immediately start a new order.
                 // Clearing it means they'd get a brand new panier next time they add an item.
                 // localStorage.removeItem('panierId');
                 // console.log('Panier ID potentially cleared after successful order.');

                 // Clean URL (optional)
                 /*
                 if (history.replaceState) {
                      const cleanURL = window.location.protocol + "//" + window.location.host + window.location.pathname;
                      history.replaceState({path:cleanURL}, '', cleanURL);
                 }
                 */
             }
        });
    </script>

    <!-- ================================================== -->
    <!-- END SCRIPT INCLUDES -->
    <!-- ================================================== -->

</body>
</html>