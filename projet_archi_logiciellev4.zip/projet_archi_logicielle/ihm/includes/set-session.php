<?php
// This script is called via AJAX after successful JS login
// It establishes the PHP session state based on data from the login API
include 'config.php'; // Starts session

$data = json_decode(file_get_contents("php://input"), true);

// Expecting 'userId' and 'token' from the login API response forwarded by JS
if (isset($data['userId'], $data['token'])) {
    $_SESSION['user_id'] = $data['userId']; // Store user ID
    $_SESSION['auth_token'] = $data['token']; // Store auth token
     // Also clear any old panier ID - it will be fetched/created next
    unset($_SESSION['panier_id']);
    error_log("PHP Session set for user ID: " . $data['userId']);
    http_response_code(200);
    echo json_encode(['status' => 'success', 'message' => 'PHP session created']);
} else {
    error_log("set-session.php: Missing userId or token in request data.");
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Missing user ID or token']);
}
?>