<?php
include 'includes/config.php'; // Inclure la config et démarrer la session
include 'includes/header.php';

// --- Récupération des Produits via API ---
$productsApiResponse = fetchFromApi('/products'); // Uses API_PRODUCTS_USERS_URL
$allProduits = [];
$errorProduits = null;

if (isset($productsApiResponse['error'])) {
    $errorProduits = "Impossible de charger les produits: " . $productsApiResponse['error'];
    error_log($errorProduits . " Status Code: " . ($productsApiResponse['statusCode'] ?? 'N/A')); // Log status code too
} elseif (is_array($productsApiResponse)) {
    $allProduits = $productsApiResponse;
} else {
     $errorProduits = "Réponse inattendue ou invalide de l'API produits.";
     error_log($errorProduits . " Réponse reçue: " . json_encode($productsApiResponse));
}

// --- Group products by category for display (optional, can be done in loop) ---
$produitsParCategorie = [];
if (is_array($allProduits)) { // Ensure it's an array before looping
    foreach ($allProduits as $produit) {
        // Basic validation of product structure
        if (isset($produit['id'], $produit['nom'])) {
            $categorie = $produit['categorie'] ?? 'Autre';
            $produitsParCategorie[$categorie][] = $produit;
        } else {
            error_log("Produit invalide reçu de l'API: " . json_encode($produit));
        }
    }
}
// --- Fin Récupération Produits ---

?>

<main class="homepage">
    <section class="hero">
        <!-- Hero content unchanged -->
        <h1>Nos Produits Frais</h1>
        <p>Directement de nos producteurs locaux.</p>
    </section>

    <div class="products-container">
        <?php if ($errorProduits): ?>
             <div class="alert error"><?= htmlspecialchars($errorProduits) ?></div>
        <?php elseif (empty($produitsParCategorie)): ?>
             <p style="text-align: center; margin: 30px 0;">Aucun produit n'est disponible pour le moment.</p>
        <?php else: ?>
             <?php foreach ($produitsParCategorie as $categorie => $produits): ?>
                 <section class="product-category">
                     <h2><?= htmlspecialchars($categorie) ?></h2>
                     <div class="products-grid">
                         <?php foreach ($produits as $produit): ?>
                             <div class="product-card">
                                  <!-- Assume image path needs constructing or is part of API response -->
                                  <!-- FIX: Close alt attribute properly -->
                                 <img src="https://placehold.co/400x300/EBF3E8/2d5a3f/png?text=<?= urlencode($produit['nom']) ?>" alt="<?= htmlspecialchars($produit['nom']) ?>">
                                 <h3><?= htmlspecialchars($produit['nom']) ?></h3>
                                 <p class="price"><?= number_format($produit['prix'] ?? 0, 2, ',', ' ') ?> € / <?= htmlspecialchars($produit['unite'] ?? 'unité') ?></p>
                                 <p class="stock">Stock: <?= htmlspecialchars($produit['stock'] ?? 'N/A') ?></p>
                                  <!-- Add to Cart Form (JS handled) -->
                                 <form class="add-to-cart-form" method="POST" data-product-id="<?= htmlspecialchars($produit['id']) ?>" data-product-unit="<?= htmlspecialchars($produit['unite'] ?? 'unité') ?>">
                                     <!-- Removed hidden inputs, using data attributes -->
                                     <div class="quantity-selector">
                                         <button type="button" class="qty-btn minus" aria-label="Diminuer quantité">-</button>
                                         <input type="number" name="quantite" value="1"
                                                min="<?= ($produit['unite'] ?? 'unité') === 'kg' ? '0.1' : '1' ?>"
                                                max="<?= htmlspecialchars($produit['stock'] ?? '999') ?>"
                                                step="<?= ($produit['unite'] ?? 'unité') === 'kg' ? '0.1' : '1' ?>"
                                                aria-label="Quantité" required>
                                         <button type="button" class="qty-btn plus" aria-label="Augmenter quantité">+</button>
                                     </div>
                                     <button type="submit" class="add-to-cart-btn">Ajouter au panier</button>
                                     <div class="add-to-cart-feedback" style="font-size: 0.8em; margin-top: 5px; color: green; display: none; text-align: center;"></div>
                                 </form>
                             </div>
                         <?php endforeach; ?>
                     </div>
                 </section>
             <?php endforeach; ?>
        <?php endif; ?>

    </div>

    <!-- Mini panier flottant -->
    <div class="floating-cart">
        <a href="/paniers.php" class="cart-link" aria-label="Voir le panier">
            <span class="cart-icon" aria-hidden="true">🛒</span>
            <span class="cart-count">0</span> <!-- Mis à jour par JS -->
        </a>
    </div>
</main>
<script src="/js/api-helpers.js" ></script>
<script >
// --- Ensure code runs after DOM is ready AND helpers are likely loaded ---
document.addEventListener('DOMContentLoaded', () => {

    // --- Check if helper functions exist before proceeding ---
    if (typeof getAuthTokenJs !== 'function' || typeof fetchApiJs !== 'function' || typeof ensurePanierExists !== 'function' || typeof updateCartCount !== 'function' || typeof setPanierIdJs !== 'function') {
        console.error("API Helper functions are not defined. Check inclusion order and content of api-helpers.js in footer.php.");
        const errorDiv = document.createElement('div');
        errorDiv.className = 'alert error';
        errorDiv.textContent = 'Erreur critique: Impossible d\'initialiser la page (fonctions manquantes).';
        document.querySelector('.products-container')?.prepend(errorDiv);
        return; // Stop execution
    }

    // --- Function Definitions specific to index.php (or potentially moved later) ---

    // Function to add/update item in the cart SPECIFICALLY FOR INDEX PAGE UI
    async function updateCartItemIndex(productId, quantity, unit, feedbackElement) {
        const token = getAuthTokenJs(); // Uses global helper
        if (!token) {
            alert("Veuillez vous connecter pour gérer votre panier.");
            window.location.href = '/login.php?redirect=index.php';
            return;
        }

        const panierId = await ensurePanierExists(); // Uses global helper
        if (!panierId) {
            feedbackElement.textContent = 'Erreur panier';
            feedbackElement.style.color = 'red';
            feedbackElement.style.display = 'block';
            setTimeout(() => { feedbackElement.style.display = 'none'; }, 2000);
            return;
        }

        feedbackElement.textContent = 'Ajout...';
        feedbackElement.style.color = 'orange';
        feedbackElement.style.display = 'block';

        try {
            // 1. GET current panier content
            const getUrl = `${API_PANIERS_URL_JS}/paniers/${panierId}`; // Uses global const
            let currentPanier;
            try {
                currentPanier = await fetchApiJs(getUrl, 'GET', null, token); // Uses global helper
            } catch (getError) {
                if (getError.status === 404) {
                    console.warn("Panier ID from localStorage invalid (404). Clearing and retrying.");
                    setPanierIdJs(null); // Uses global helper
                    const newPanierId = await ensurePanierExists(); // Uses global helper
                    if (!newPanierId) throw new Error("Impossible de recréer le panier après erreur 404.");
                    currentPanier = { panierId: newPanierId, panierProduits: [] };
                } else {
                    throw getError;
                }
            }

            let panierProduits = currentPanier?.panierProduits || [];

            // 2. Find if product exists and update/add
            const existingItemIndex = panierProduits.findIndex(item => item.productId === productId);
            let itemExisted = false;
            if (existingItemIndex > -1) {
                itemExisted = true;
                panierProduits[existingItemIndex].quantity = quantity;
                console.log(`Item ${productId} quantity updated to ${quantity}.`);
            } else {
                 // Ensure quantity is positive before adding
                 if (quantity > 0 || (unit === 'kg' && quantity >= 0.1) ) {
                     panierProduits.push({ productId: productId, quantity: quantity, unit: unit });
                     console.log(`Item ${productId} added with quantity ${quantity}.`);
                 } else {
                      console.log(`Item ${productId} not added due to zero/negative quantity.`);
                      feedbackElement.textContent = ''; feedbackElement.style.display = 'none';
                      return; // Don't PUT if nothing changed
                 }
            }

            // Remove item if quantity becomes effectively zero
            panierProduits = panierProduits.filter(item => !(item.productId === productId && (item.quantity <= 0 && (item.unit !== 'kg' || item.quantity < 0.1))));


            // 3. PUT the *entire updated* list back
            const putUrl = `${API_PANIERS_URL_JS}/paniers/${panierId}`; // Uses global const
            const panierPayload = {
                panierId: parseInt(panierId),
                panierProduits: panierProduits
            };

            await fetchApiJs(putUrl, 'PUT', panierPayload, token); // Uses global helper

            // 4. Success: Update UI
            console.log("Panier updated successfully via PUT.");
            await updateCartCount(); // Uses global helper
            feedbackElement.textContent = itemExisted ? 'Quantité mise à jour!' : 'Ajouté !';
            feedbackElement.style.color = 'green';
            setTimeout(() => { feedbackElement.style.display = 'none'; }, 1500);

        } catch (error) {
            console.error("Error updating cart item:", error);
            alert("Erreur lors de la mise à jour du panier: " + error.message);
            feedbackElement.textContent = 'Erreur';
            feedbackElement.style.color = 'red';
            setTimeout(() => { feedbackElement.style.display = 'none'; }, 3000);
        }
    }


    // --- Event Listeners Setup ---

    // --- Gestion des quantités (+/- buttons) ---
    document.querySelectorAll('.quantity-selector').forEach(selector => {
        const minus = selector.querySelector('.qty-btn.minus');
        const plus = selector.querySelector('.qty-btn.plus');
        const input = selector.querySelector('input[name="quantite"]');
        if (!input) return;

        const step = parseFloat(input.step) || 1;
        const min = parseFloat(input.min) || 0;
        const maxAttr = input.getAttribute('max');
        const max = maxAttr && !isNaN(parseFloat(maxAttr)) ? parseFloat(maxAttr) : Infinity;

        minus?.addEventListener('click', () => {
            let currentValue = parseFloat(input.value) || min;
            let newValue = currentValue - step;
            if (step < 1) newValue = parseFloat(newValue.toFixed(1));
            newValue = Math.max(min, newValue);
            input.value = newValue;
            input.dispatchEvent(new Event('change', { bubbles: true }));
        });

        plus?.addEventListener('click', () => {
            let currentValue = parseFloat(input.value) || min;
            let newValue = currentValue + step;
            if (step < 1) newValue = parseFloat(newValue.toFixed(1));
            newValue = Math.min(max, newValue);
            input.value = newValue;
            input.dispatchEvent(new Event('change', { bubbles: true }));
        });

        input?.addEventListener('change', () => {
            let currentValue = parseFloat(input.value);
            if (isNaN(currentValue) || currentValue < min) {
                input.value = min;
            } else if (currentValue > max) {
                input.value = max;
            } else if (step < 1) {
                const roundedValue = Math.round(currentValue / step) * step;
                input.value = parseFloat(roundedValue.toFixed(1));
            } else {
                input.value = Math.round(currentValue);
            }
        });
    });

    // --- Écouteur pour les ajouts au panier ---
    document.querySelectorAll('.add-to-cart-form').forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const submitButton = form.querySelector('.add-to-cart-btn');
            if (!submitButton) return;
            submitButton.disabled = true;

            const productId = form.dataset.productId;
            const unit = form.dataset.productUnit;
            const quantiteInput = form.querySelector('input[name="quantite"]');
            const quantity = parseFloat(quantiteInput.value);
            const feedback = form.querySelector('.add-to-cart-feedback');
            const minQuantity = parseFloat(quantiteInput.min) || 0;

            if (isNaN(quantity) || quantity < minQuantity) {
                 if (minQuantity > 0) {
                      alert(`Quantité invalide. Minimum requis: ${minQuantity} ${unit}.`);
                      submitButton.disabled = false;
                      return;
                 }
            }

            // Call the updateCartItemIndex function defined above
            updateCartItemIndex(productId, quantity, unit, feedback)
                .catch(err => {
                     console.error("Add to cart failed:", err);
                })
                .finally(() => {
                    submitButton.disabled = false;
                });
        });
    });

    // --- Initialisation au chargement de la page ---
    // Call the *global* updateCartCount function from api-helpers.js
    updateCartCount();

}); // End of DOMContentLoaded listener
</script>

<?php include 'includes/footer.php'; ?>