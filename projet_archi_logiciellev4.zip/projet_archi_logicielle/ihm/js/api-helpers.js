// ihm/js/api-helpers.js

// Define constants first
const API_PRODUCTS_USERS_URL_JS = 'http://localhost:8080/utilisateur/api';
const API_PANIERS_URL_JS = 'http://localhost:8080/paniers/api';
const API_COMMANDES_URL_JS = 'http://localhost:8080/commandes/api';

// Define functions directly in the global scope
function getAuthTokenJs() {
    return localStorage.getItem('authToken');
}
function getUserIdJs() {
    return localStorage.getItem('userId');
}
function getPanierIdJs() {
    return localStorage.getItem('panierId');
}
function setPanierIdJs(panierId) {
    if (panierId) {
        localStorage.setItem('panierId', panierId);
    } else {
        localStorage.removeItem('panierId');
    }
}

// Generic API Fetch for JS
async function fetchApiJs(url, method = 'GET', data = null, token = null) {
    const headers = {
        'Accept': 'application/json'
    };
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    const options = {
        method: method.toUpperCase(),
        headers: headers,
        cache: 'no-cache'
    };
    if (data && ['POST', 'PUT', 'PATCH'].includes(options.method)) {
        headers['Content-Type'] = 'application/json';
        options.body = JSON.stringify(data);
    }
    console.log(`JS Fetch: ${options.method} ${url}`);
    try {
        const response = await fetch(url, options);
        const responseText = await response.text();
        let responseData = null;
        try { responseData = responseText ? JSON.parse(responseText) : null; } catch (e) {
             if (response.ok && responseText) { responseData = { responseText: responseText }; }
             else { console.error("JSON Parsing Error:", e, responseText);
                 if (!response.ok) { const error = new Error(responseText || `Erreur ${response.status}`); error.status = response.status; throw error; }
                 throw new Error("Invalid JSON response");
             }
        }
        if (!response.ok) {
            const message = responseData?.message || responseData?.error || responseData?.responseText || response.statusText || `Erreur ${response.status}`;
            console.error(`API Error (${options.method} ${url}): ${response.status}`, responseData);
            const error = new Error(message); error.status = response.status; error.data = responseData; throw error;
        }
        if (typeof responseData === 'object' && responseData?.responseText && ['created', 'updated', 'deleted'].includes(responseData.responseText)) { return { success: true, message: responseData.responseText }; }
        if (response.status === 204) { return { success: true, status: 204 }; }
        return responseData;
    } catch (error) { console.error(`Fetch API Error (${options.method} ${url}):`, error); throw error; }
}

// Function to ensure a panier exists
async function ensurePanierExists() {
    const token = getAuthTokenJs();
    const userId = getUserIdJs();
    if (!token || !userId) return null;
    let panierId = getPanierIdJs();
    if (panierId) return panierId;
    console.log("No panierId, attempting to create one.");
    try {
        const createUrl = `${API_PANIERS_URL_JS}/paniers`;
        const newPanier = await fetchApiJs(createUrl, 'POST', {}, token); // Send empty object
        if (newPanier?.panierId) {
            console.log("New panier created with ID:", newPanier.panierId);
            setPanierIdJs(newPanier.panierId);
            return newPanier.panierId;
        } else { throw new Error("Failed to create panier or get ID from response."); }
    } catch (error) { console.error("Error ensuring panier exists:", error); return null; }
}

// Function to update the floating cart count
async function updateCartCount() {
    const token = getAuthTokenJs();
    const panierId = getPanierIdJs();
    const cartCountElement = document.querySelector('.cart-count');
    if (!cartCountElement) return;
    if (!token || !panierId) { cartCountElement.textContent = '0'; return; }
    const apiUrl = `${API_PANIERS_URL_JS}/paniers/${panierId}`;
    try {
        const panierData = await fetchApiJs(apiUrl, 'GET', null, token);
        const count = panierData?.panierProduits?.length ?? 0;
        cartCountElement.textContent = count;
    } catch (error) {
        console.warn("Erreur récupération compte panier:", error.message);
        if (error.status === 404) { setPanierIdJs(null); cartCountElement.textContent = '0'; }
        else { console.error("Impossible de mettre à jour le compteur du panier:", error); }
    }
}

console.log("api-helpers.js loaded and functions defined."); // Verification log