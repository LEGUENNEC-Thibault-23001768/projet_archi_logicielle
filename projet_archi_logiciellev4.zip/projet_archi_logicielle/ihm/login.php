<?php
include 'includes/config.php';
// Don't include api-requests.php, use config.php's fetchFromApi

// If already logged in via PHP session, redirect
if (getUserId()) {
    header('Location: /espace-client.php'); // Or index.php
    exit();
}

$error_message = $_GET['error'] ?? null;
$success_message = $_GET['success'] ?? null; // For messages from register page
$redirect_url = $_GET['redirect'] ?? '/index.php'; // Default redirect after login

include 'includes/header.php';
?>

<main class="auth-page">
    <div class="auth-container">
        <h1>Connexion</h1>

        <div id="error-container" class="alert error" style="display: <?= $error_message ? 'block' : 'none' ?>;">
            <?= htmlspecialchars($error_message ?? '') ?>
        </div>
        <div id="success-container" class="alert success" style="display: <?= $success_message ? 'block' : 'none' ?>;">
             <?= htmlspecialchars($success_message ?? '') ?>
        </div>

        <form id="login-form" method="POST"> <!-- No action needed, handled by JS -->
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="form-group">
                <label for="password">Mot de passe</label>
                <input type="password" id="password" name="password" required>
            </div>

            <button type="submit" class="auth-button">Se connecter</button>
        </form>

        <div class="auth-links">
            <p>Pas encore de compte ? <a href="/register.php">S'inscrire</a></p>
            <!-- <a href="/forgot-password.php" class="forgot-password">Mot de passe oublié ?</a> -->
        </div>
    </div>
</main>

<script>
// Use constants defined in footer.php
const redirectUrl = <?= json_encode($redirect_url) ?>;

document.getElementById('login-form')?.addEventListener('submit', function(e) {
    e.preventDefault();
    const form = e.target;
    const email = form.email.value;
    const password = form.password.value; // Changed from motDePasse to match Java DTO likely expectation
    const errorContainer = document.getElementById('error-container');
    const successContainer = document.getElementById('success-container');
    const submitButton = form.querySelector('button[type="submit"]');

    errorContainer.textContent = ''; // Clear previous errors
    errorContainer.style.display = 'none';
    successContainer.textContent = '';
    successContainer.style.display = 'none';
    submitButton.disabled = true;
    submitButton.textContent = 'Connexion...';

    // API endpoint from Produits/Utilisateurs service
    const apiUrl = `${API_PRODUCTS_USERS_URL_JS}/auth/login`;

    fetch(apiUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        // Ensure payload matches LoginCredentials.java expected fields
        body: JSON.stringify({
            email: email,
            password: password // Send 'password' field
        })
    })
    .then(async response => { // Use async to easily handle await response.json()
        const responseData = await response.json().catch(() => null); // Try to parse JSON even for errors
        if (!response.ok) {
            // Prioritize error message from API response body if available
            const message = responseData?.message || responseData?.error || (response.status === 401 ? 'Email ou mot de passe incorrect.' : `Erreur ${response.status}`);
            throw new Error(message);
        }
        return responseData; // This should be the User object (without password) + potentially a token field
    })
    .then(userData => {
         // --- Authentication Success ---
        console.log('Login successful:', userData);
        successContainer.textContent = 'Connexion réussie ! Préparation de votre session...';
        successContainer.style.display = 'block';

        // **IMPORTANT**: Store User ID and AUTH TOKEN in localStorage for JS access
        // We assume the login API returns 'id' for the user ID and 'token' for the JWT (ADJUST IF NEEDED)
        // For now, since the Java code doesn't explicitly return a JWT, we'll use a placeholder
        // or simulate one based on user ID for testing. Let's assume user ID is enough for now.
        // A REAL JWT implementation is needed on the Java side for proper security.
        const userId = userData?.id; // Get user ID from response
        const authToken = userData?.token || `FAKE_JWT_TOKEN_FOR_${userId}`; // USE ACTUAL TOKEN if returned, else fake it

        if (!userId) {
             throw new Error("ID utilisateur manquant dans la réponse de connexion.");
        }

        localStorage.setItem('authToken', authToken);
        localStorage.setItem('userId', userId);
        localStorage.removeItem('panierId'); // Clear old panier ID on login

         // --- Set PHP Session (async background call) ---
         // Send userId and token to PHP to establish server-side session
         fetch('/includes/set-session.php', {
             method: 'POST',
             headers: { 'Content-Type': 'application/json' },
             body: JSON.stringify({
                 userId: userId,
                 token: authToken // Send the token to store in session too
             })
         })
         .then(sessionResponse => sessionResponse.json())
         .then(sessionResult => {
             if (sessionResult.status === 'success') {
                 console.log("PHP session created successfully.");
                 // Now that session is set, redirect
                 window.location.href = redirectUrl;
             } else {
                 throw new Error(sessionResult.message || "Erreur lors de la création de la session PHP.");
             }
         })
         .catch(sessionError => {
             // Handle session setting error (e.g., show message, but maybe still proceed?)
             console.error('PHP Session Error:', sessionError);
             errorContainer.textContent = 'Erreur session: ' + sessionError.message;
             errorContainer.style.display = 'block';
              // Allow proceeding maybe, but log the error
              // setTimeout(() => { window.location.href = redirectUrl; }, 1500); // Optional delay
               submitButton.disabled = false; // Re-enable button if session fails critically
               submitButton.textContent = 'Se connecter';
         });

    })
    .catch(error => {
        console.error('Login Error:', error);
        errorContainer.textContent = error.message;
        errorContainer.style.display = 'block';
        submitButton.disabled = false;
        submitButton.textContent = 'Se connecter';
    });
});
</script>

<?php include 'includes/footer.php'; ?>