<?php
include 'includes/config.php'; // Starts session

// Clear PHP session data
unset($_SESSION['user_id']);
unset($_SESSION['auth_token']);
unset($_SESSION['panier_id']);

// Optional: Destroy the session completely
// session_destroy();

// Redirect to homepage or login page
header('Location: /index.php?logout=1'); // Add param to potentially show a message
exit();
?>
