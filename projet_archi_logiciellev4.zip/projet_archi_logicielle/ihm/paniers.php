<?php
include 'includes/config.php'; // Inclure la config et démarrer la session
include 'includes/header.php';

$panierData = null;
$produitsDetails = []; // To store fetched product details
$error = null;
$token = getAuthToken(); // Get token from PHP session (set via set-session.php)
$userId = getUserId(); // Get user ID from PHP session
$panierId = getCurrentPanierId(); // Get panier ID from PHP session (needs to be set)

// --- Logic to get Panier ID if not in session (fallback to JS local storage if needed) ---
// This part is tricky because the primary panier ID management is now in JS localStorage.
// PHP pages might need the ID too. We could pass it via URL or try fetching it.
// Let's assume for now JS handles panier ID persistence, and PHP pages either
// get it from the session (if synced) or rely on JS to manage cart display/actions.
// We'll fetch the panier using JS localStorage ID if PHP session doesn't have it.

if (!$token || !$userId) {
    $error = "Veuillez vous connecter pour voir votre panier.";
} else {
     // Try to get panier ID - JS should manage this primarily via localStorage
     // If PHP needs it, it should be synced to session or passed in URL/POST
     // For this page, we'll let JS fetch and render the cart content dynamically.
     // PHP will just provide the basic structure.
     $panierIdFromSession = getCurrentPanierId(); // Check if PHP session has it
     // If needed, PHP could try to fetch it, but it's complex without a /paniers/current endpoint.
}
?>

<main class="panier-page">
    <h1>Votre Panier</h1>

    <div id="panier-loading" style="text-align: center; padding: 30px;">Chargement du panier...</div>
    <div id="panier-error" class="alert error" style="display: none;"></div>
    <div id="panier-empty" class="empty-cart" style="display: none;">
        <p>Votre panier est vide.</p>
        <a href="/index.php" class="browse-btn">Parcourir nos produits</a>
    </div>

    <div id="panier-content-container" style="display: none;">
        <div class="cart-items" id="cart-items-list">
            <!-- Cart items will be rendered here by JavaScript -->
            <div class="cart-item-template" style="display: none;"> <!-- Template for JS cloning -->
                <img src="/images/placeholder.jpg" alt="Produit" class="item-image">
                <div class="item-info">
                    <h3 class="item-name">Nom du produit</h3>
                    <p class="unit-price">0.00 € / unité</p>
                </div>
                <div class="item-quantity">
                    <form class="update-form">
                        <button type="button" class="qty-btn minus" aria-label="Diminuer">-</button>
                        <input type="number" name="quantite" value="1" min="1" step="1" aria-label="Quantité">
                        <button type="button" class="qty-btn plus" aria-label="Augmenter">+</button>
                    </form>
                </div>
                <div class="item-total">
                    <p class="item-total-price">0.00 €</p>
                </div>
                <form class="remove-form">
                     <input type="hidden" name="productId" value="">
                    <button type="submit" class="remove-btn" aria-label="Supprimer">🗑️</button>
                </form>
            </div>
        </div>

        <div class="cart-summary" id="cart-summary-details">
            <div class="summary-row">
                <span>Sous-total</span>
                <span id="summary-subtotal">0.00 €</span>
            </div>
            <!-- <div class="summary-row">
                <span>Livraison</span>
                <span>Gratuite</span>
            </div> -->
            <div class="summary-row total">
                <span>Total</span>
                <span id="summary-total">0.00 €</span>
            </div>

            <button id="checkout-btn" class="checkout-btn disabled" disabled>Passer la commande</button>
             <div id="checkout-error" style="color: red; text-align: center; margin-top: 10px; font-size: 0.9em;"></div>
        </div>
    </div>
</main>

<script>
// --- Cart Rendering and Interaction Logic ---
const panierLoading = document.getElementById('panier-loading');
const panierError = document.getElementById('panier-error');
const panierEmpty = document.getElementById('panier-empty');
const panierContainer = document.getElementById('panier-content-container');
const cartItemsList = document.getElementById('cart-items-list');
const itemTemplate = document.querySelector('.cart-item-template'); // Template for cloning
const summarySubtotal = document.getElementById('summary-subtotal');
const summaryTotal = document.getElementById('summary-total');
const checkoutBtn = document.getElementById('checkout-btn');
const checkoutError = document.getElementById('checkout-error');

// Use helper functions defined in index.php (or move to global.js)
// Assume getAuthTokenJs, getUserIdJs, getPanierIdJs, setPanierIdJs, fetchApiJs are available

let currentPanierData = null; // Store fetched panier data
let productDetailsCache = {}; // Cache for product details

// Function to fetch details for a single product
async function fetchProductDetails(productId, token) {
    if (productDetailsCache[productId]) {
        return productDetailsCache[productId];
    }
    if (!productId) return null;

    try {
        const url = `${API_PRODUCTS_USERS_URL_JS}/products/${productId}`;
        const details = await fetchApiJs(url, 'GET', null, token);
        productDetailsCache[productId] = details || { nom: `Produit ${productId} (introuvable)`, prix: 0, image: 'placeholder.jpg' }; // Provide fallback
        return productDetailsCache[productId];
    } catch (error) {
        console.error(`Error fetching details for product ${productId}:`, error);
        productDetailsCache[productId] = { nom: `Produit ${productId} (erreur)`, prix: 0, image: 'placeholder.jpg' }; // Cache error state
        return productDetailsCache[productId];
    }
}

// Function to render the cart items
async function renderCart(panier) {
     cartItemsList.innerHTML = ''; // Clear previous items (excluding template)
     let subtotal = 0;
     const token = getAuthTokenJs();

     if (!panier || !panier.panierProduits || panier.panierProduits.length === 0) {
         panierEmpty.style.display = 'block';
         panierContainer.style.display = 'none';
         checkoutBtn.disabled = true;
         checkoutBtn.classList.add('disabled');
         checkoutError.textContent = '';
         return;
     }

     // Fetch details for all products in parallel
     const detailPromises = panier.panierProduits.map(item => fetchProductDetails(item.productId, token));
     await Promise.all(detailPromises); // Wait for all details to be fetched (or fail)

     // Now render using cached details
     panier.panierProduits.forEach(item => {
         const details = productDetailsCache[item.productId];
         if (!details) return; // Skip if details failed catastrophically

         const itemElement = itemTemplate.cloneNode(true);
         itemElement.classList.remove('cart-item-template');
         itemElement.style.display = ''; // Make it visible
         itemElement.dataset.productId = item.productId; // Add dataset for easier selection

         itemElement.querySelector('.item-image').src = `/images/${details.image || 'placeholder.jpg'}`;
         itemElement.querySelector('.item-image').alt = details.nom || 'Produit';
         itemElement.querySelector('.item-name').textContent = details.nom || 'Produit inconnu';
         itemElement.querySelector('.unit-price').textContent = `${(details.prix || 0).toFixed(2)} € / ${item.unit}`;

         const quantityInput = itemElement.querySelector('input[name="quantite"]');
         const unit = item.unit;
         const step = unit === 'kg' ? 0.1 : 1;
         const min = unit === 'kg' ? 0.1 : 1; // Allow 0 for removal? No, handle via remove button. Min should be 1 or 0.1
         quantityInput.value = item.quantity;
         quantityInput.step = step;
         quantityInput.min = min; // Minimum add is step or 1

         const itemTotalPriceElement = itemElement.querySelector('.item-total-price');
         const lineTotal = (details.prix || 0) * item.quantity;
         itemTotalPriceElement.textContent = `${lineTotal.toFixed(2)} €`;
         subtotal += lineTotal;

         // Attach event listeners for quantity changes and removal to the CLONED element
         attachItemEventListeners(itemElement, item.productId, unit, min, step);
         itemElement.querySelector('.remove-form input[name="productId"]').value = item.productId;


         cartItemsList.appendChild(itemElement);
     });

     // Update summary
     summarySubtotal.textContent = `${subtotal.toFixed(2)} €`;
     summaryTotal.textContent = `${subtotal.toFixed(2)} €`; // Assuming no extra costs yet

     // Enable checkout if items exist
     checkoutBtn.disabled = false;
     checkoutBtn.classList.remove('disabled');
     checkoutError.textContent = '';
     panierContainer.style.display = 'block'; // Show the container
     panierEmpty.style.display = 'none';
}

// Function to attach listeners to a specific cart item element
function attachItemEventListeners(itemElement, productId, unit, min, step) {
    const form = itemElement.querySelector('.update-form');
    const input = form.querySelector('input[name="quantite"]');
    const minus = form.querySelector('.minus');
    const plus = form.querySelector('.plus');
    const removeForm = itemElement.querySelector('.remove-form');

    async function handleQuantityUpdate(newQuantity) {
        const token = getAuthTokenJs();
        const panierId = getPanierIdJs();
        if (!token || !panierId || !currentPanierData) return;

        console.log(`Updating ${productId} to quantity ${newQuantity}`);
        input.disabled = true; // Disable input during update
        minus.disabled = true;
        plus.disabled = true;

        // Find index in current data
        const itemIndex = currentPanierData.panierProduits.findIndex(p => p.productId === productId);
        if (itemIndex === -1) {
            console.error("Item not found in current data?");
            input.disabled = false; minus.disabled = false; plus.disabled = false;
            return;
        }

        // Prepare updated list
        let updatedProduits = [...currentPanierData.panierProduits];
        updatedProduits[itemIndex].quantity = newQuantity;

        // Prepare PUT payload
        const putUrl = `${API_PANIERS_URL_JS}/paniers/${panierId}`;
        const panierPayload = {
             panierId: parseInt(panierId),
             panierProduits: updatedProduits
        };

        try {
            const updatedPanier = await fetchApiJs(putUrl, 'PUT', panierPayload, token);
            currentPanierData = updatedPanier; // Update local data state
            await renderCart(currentPanierData); // Re-render the whole cart
        } catch (error) {
            alert("Erreur de mise à jour: " + error.message);
             // Re-enable inputs on error, maybe revert display?
            input.disabled = false; minus.disabled = false; plus.disabled = false;
             // Re-render to potentially reset view based on last successful state
             await renderCart(currentPanierData);
        } finally {
             // Re-enable button is handled by re-render
        }
    }

     async function handleItemRemoval() {
         const token = getAuthTokenJs();
         const panierId = getPanierIdJs();
         if (!token || !panierId || !currentPanierData) return;
         if (!confirm(`Supprimer "${itemElement.querySelector('.item-name').textContent}" du panier ?`)) return;

         console.log(`Removing ${productId}`);
         itemElement.style.opacity = '0.5'; // Indicate processing

         // Prepare updated list (filter out the item)
         let updatedProduits = currentPanierData.panierProduits.filter(p => p.productId !== productId);

         // Prepare PUT payload
         const putUrl = `${API_PANIERS_URL_JS}/paniers/${panierId}`;
         const panierPayload = {
              panierId: parseInt(panierId),
              panierProduits: updatedProduits
         };

         try {
             const updatedPanier = await fetchApiJs(putUrl, 'PUT', panierPayload, token);
             currentPanierData = updatedPanier; // Update local data state
             await renderCart(currentPanierData); // Re-render the whole cart
         } catch (error) {
             alert("Erreur de suppression: " + error.message);
             itemElement.style.opacity = '1'; // Restore opacity on error
             await renderCart(currentPanierData); // Re-render
         }
     }


    minus.addEventListener('click', () => {
        let currentVal = parseFloat(input.value);
        let newVal = currentVal - step;
        if (step < 1) newVal = parseFloat(newVal.toFixed(1));
        newVal = Math.max(min, newVal); // Respect min value
        if (newVal !== currentVal) {
            input.value = newVal;
            handleQuantityUpdate(newVal);
        }
    });

    plus.addEventListener('click', () => {
        let currentVal = parseFloat(input.value);
        // TODO: Check against actual product stock if available in details
        let newVal = currentVal + step;
        if (step < 1) newVal = parseFloat(newVal.toFixed(1));
        // Add max check here if needed: newVal = Math.min(maxStock, newVal);
        if (newVal !== currentVal) {
            input.value = newVal;
             handleQuantityUpdate(newVal);
        }
    });

    input.addEventListener('change', () => { // Handle typed input
        let currentVal = parseFloat(input.value);
        let newVal = currentVal;
         if (isNaN(newVal) || newVal < min) {
             newVal = min;
         } else if (step < 1) {
             newVal = parseFloat(newVal.toFixed(1));
         }
         // Add max check here if needed
         if (newVal !== currentVal) {
              input.value = newVal; // Correct the input display
              handleQuantityUpdate(newVal);
         } else if (input.value !== String(newVal)) {
              input.value = newVal; // Fix display if needed (e.g., NaN entered)
         }
    });

    removeForm.addEventListener('submit', (e) => {
         e.preventDefault();
         handleItemRemoval();
    });
}


// --- Load Cart on Page Load ---
async function loadCart() {
    const token = getAuthTokenJs();
    const userId = getUserIdJs();

    panierLoading.style.display = 'block';
    panierError.style.display = 'none';
    panierEmpty.style.display = 'none';
    panierContainer.style.display = 'none';

    if (!token || !userId) {
        panierLoading.style.display = 'none';
        panierError.textContent = "Veuillez vous connecter pour voir votre panier.";
        panierError.style.display = 'block';
        // Optional: Add login button here
        return;
    }

    let panierId = getPanierIdJs();

    if (!panierId) {
         // If no ID in localStorage, try to create/fetch one
         console.log("Attempting to ensure panier exists as none found in localStorage.");
         panierId = await ensurePanierExists(); // ensurePanierExists is defined in index.php script part - ideally move to global.js
         if (!panierId) {
             panierLoading.style.display = 'none';
             panierError.textContent = "Impossible de charger ou créer votre panier.";
             panierError.style.display = 'block';
             return;
         }
    }

     // Now fetch the panier data using the obtained ID
    const apiUrl = `${API_PANIERS_URL_JS}/paniers/${panierId}`;
    try {
        const panierData = await fetchApiJs(apiUrl, 'GET', null, token);
        currentPanierData = panierData; // Store the fetched data
        await renderCart(currentPanierData); // Render the cart items
        panierLoading.style.display = 'none';

    } catch (error) {
         panierLoading.style.display = 'none';
          // If panier not found (404), clear local storage and show empty message
         if (error.status === 404) {
              console.log("Panier non trouvé (404), réinitialisation localStorage.");
              setPanierIdJs(null); // Remove invalid ID
              panierEmpty.style.display = 'block';
         } else {
             panierError.textContent = "Erreur lors du chargement du panier: " + error.message;
             panierError.style.display = 'block';
         }
    }
}

// --- Checkout Button ---
checkoutBtn.addEventListener('click', () => {
     const panierId = getPanierIdJs();
     if (!panierId || !currentPanierData || !currentPanierData.panierProduits || currentPanierData.panierProduits.length === 0) {
          checkoutError.textContent = 'Votre panier est vide ou indisponible.';
          return;
     }
     // Redirect to the commande page, passing the panier ID
     window.location.href = `/commandes.php?panierId=${panierId}`;
});


// --- Initial Load ---
document.addEventListener('DOMContentLoaded', loadCart);

</script>

<?php include 'includes/footer.php'; ?>