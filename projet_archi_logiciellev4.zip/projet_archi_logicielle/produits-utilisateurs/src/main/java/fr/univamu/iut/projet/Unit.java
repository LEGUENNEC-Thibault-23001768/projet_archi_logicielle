package fr.univamu.iut.projet;

public enum Unit {
    KILOGRAM, UNIT, DOZEN
}